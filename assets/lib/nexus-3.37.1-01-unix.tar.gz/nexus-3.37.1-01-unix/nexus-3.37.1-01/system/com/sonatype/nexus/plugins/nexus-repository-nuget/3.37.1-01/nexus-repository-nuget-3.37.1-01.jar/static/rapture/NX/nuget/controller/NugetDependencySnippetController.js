/*
 * Copyright (c) 2008-present Sonatype, Inc.
 *
 * All rights reserved. Includes the third-party code listed at http://links.sonatype.com/products/nexus/pro/attributions
 * Sonatype and Sonatype Nexus are trademarks of Sonatype, Inc. Apache Maven is a trademark of the Apache Foundation.
 * M2Eclipse is a trademark of the Eclipse Foundation. All other trademarks are the property of their respective owners.
 */
/*global Ext, NX*/

/**
 * Nuget controller.
 *
 * @since 3.15
 */
Ext.define('NX.nuget.controller.NugetDependencySnippetController', {
  extend: 'NX.app.Controller',

  /**
   * @override
   */
  init: function() {
    NX.getApplication().getDependencySnippetController()
        .addDependencySnippetGenerator('nuget', this.snippetGenerator);
  },

  snippetGenerator: function(componentModel, assetModel) {
    var name = componentModel.get('name'),
        version = componentModel.get('version');

    return [
      {
        displayName: 'Package Manager',
        snippetText: 'Install-Package ' + name + ' -Version ' + version
      }, {
        displayName: '.NET CLI',
        snippetText: 'dotnet add package ' + name + ' --version ' + version
      }, {
        displayName: 'Paket CLI',
        snippetText: 'paket add ' + name + ' --version ' + version
      }
    ];
  }
});
